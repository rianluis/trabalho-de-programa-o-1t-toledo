let inputNumero = document.querySelector("#inputNumero");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalDias(){
    let numero = Number (inputNumero.value);

    let centena = Math.floor (numero / 100);
    let dezena = Math.floor((numero % 100) / 10);
    let unidade = Math.floor(numero % 100 % 10);

    h3Resultado.innerHTML= "Total de centenas &eacute;: " + centena.toFixed(0) + "<br>" + "Total de dezenas &eacute;: " + dezena.toFixed(0) + "<br>" + "Total de unidades &eacute;: " + unidade.toFixed(0);
}
btCalcular.onclick = function(){    
    calcularTotalDias();
}