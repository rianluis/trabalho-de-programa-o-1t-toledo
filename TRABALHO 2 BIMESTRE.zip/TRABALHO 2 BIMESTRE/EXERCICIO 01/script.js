let inputLargura = document.querySelector("#inputLargura");
let inputComprimento = document.querySelector("#inputComprimento");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");


function calcularTotalTerreno(){
    let Largura = Number (inputLargura.value);
    let Comprimento = Number (inputComprimento.value);

    if(Largura === Comprimento){
        h3Resultado.innerHTML = 
        "O terreno n&atilde;o &eacute; retangular.";
    }else{
        h3Resultado.innerHTML= "Valor Total da &aacute;rea: "+Largura * Comprimento + "m&sup2;.";
    }

    
}

btCalcular.onclick = function(){
    calcularTotalTerreno();
}