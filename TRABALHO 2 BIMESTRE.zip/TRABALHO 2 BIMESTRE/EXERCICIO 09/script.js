let inputX1 = document.querySelector("#inputX1");
let inputX2 = document.querySelector("#inputX2");
let inputY1 = document.querySelector("#inputY1");
let inputY2 = document.querySelector("#inputY2");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalArea(){
    let X1 = Number (inputX1.value);
    let X2 = Number (inputX2.value);
    let Y1 = Number (inputY1.value);
    let Y2 = Number (inputY2.value);



    h3Resultado.innerHTML= "A dist&acirc;ncia entre o ponto um e o ponto dois &eacute; " + ((X2-X1)*2 + (Y2 - Y1)*2) + " unidades.";
}
btCalcular.onclick = function(){    
    calcularTotalArea();
}