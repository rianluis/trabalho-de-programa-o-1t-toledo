let inputValor = document.querySelector("#inputValor");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalDias(){
    let valor = Number (inputValor.value);

    let valorDividido = Math.floor(valor / 3);
    let carlos = Math.floor(valorDividido);
    let andre = Math.floor(valorDividido);
    let felipe = valor - (carlos + andre);

    h3Resultado.innerHTML= "Total para Carlos pagar: R$ " + carlos.toFixed(2) + "<br>" + "Total para Andr&eacute; pagar: R$ " + andre.toFixed(2) + "<br>" + "Total para Felipe pagar: R$ " + felipe.toFixed(2);
}
btCalcular.onclick = function(){    
    calcularTotalDias();
}