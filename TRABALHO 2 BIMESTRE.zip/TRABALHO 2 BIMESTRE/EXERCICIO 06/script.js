let inputQtdadeCavalos = document.querySelector ("#inputPesoRefeicao");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularTotalRefeicao(){
    let precoRefeicao = Number (inputPesoRefeicao.value);
    let pesoRefeicao = Number (inputPesoRefeicao.value);

    h3Resultado.innerHTML= "Peso total prato " + (pesoRefeicao - 0.100).toFixed(2) + "kg" + "<br>" + "Valor &aacute; pagar R$ "+ ((precoRefeicao - 0.100) * 12).toFixed(2) ; 
    h3Resultado.textinput = maxlength ("2");
}

btCalcular.onclick = function(){
    calcularTotalRefeicao();
}