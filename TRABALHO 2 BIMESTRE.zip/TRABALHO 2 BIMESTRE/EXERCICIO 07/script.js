let inputDia = document.querySelector("#inputDia");
let inputMes = document.querySelector("#inputMes");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalDias(){
    let dia = Number (inputDia.value);
    let mes = Number (inputMes.value);

    h3Resultado.innerHTML= "Passaram " + (((mes-1) * 30) + dia) + " dias desde inicio do ano";
}
btCalcular.onclick = function(){    
    calcularTotalDias();
}