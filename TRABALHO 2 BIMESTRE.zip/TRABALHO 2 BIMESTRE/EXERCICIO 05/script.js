let inputQtdadeCavalos = document.querySelector ("#inputVlrAbast");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularTotalAbastecido(){
    let VlrAbast = Number (inputVlrAbast.value);

    h3Resultado.innerHTML= "Foram abastecidos: "+ (VlrAbast / 4.93).toFixed(2) + " litros.";
}

btCalcular.onclick = function(){
    calcularTotalAbastecido();
}