let inputRaioPizza = document.querySelector ("#inputRaioPizza");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularTotalFerraduras(){
    let raioPizza= Number (inputRaioPizza.value);

    h3Resultado.innerHTML= "A &aacute;rea total da pizza &eacute; "+ (Math.pow(raioPizza,2))*3.14.toFixed(2) + " cm&sup2;";
}   

btCalcular.onclick = function(){
    calcularTotalFerraduras();
}