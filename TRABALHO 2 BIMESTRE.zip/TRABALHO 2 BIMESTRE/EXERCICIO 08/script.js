let inputPequena = document.querySelector("#inputPequena");
let inputMedia = document.querySelector("#inputMedia");
let inputGrande = document.querySelector("#inputGrande");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalCamisa(){
    let pequena = Number (inputPequena.value);
    let media = Number (inputMedia.value);
    let grande = Number (inputGrande.value);

    let totalPq = (pequena * 10);
    let totalMd = (media * 12);
    let totalGd = (grande * 15);
       
    
    h3Resultado.innerHTML= "Valor arrecadado é R$ " + (totalPq + totalMd + totalGd).toFixed(2) + " em camisetas."
}
btCalcular.onclick = function(){    
    calcularTotalCamisa();
}