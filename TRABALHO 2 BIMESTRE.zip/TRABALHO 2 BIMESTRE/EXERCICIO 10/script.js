let inputDias = document.querySelector("#inputDias");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalDias(){
    let dias = Number (inputDias.value);

    let anos = (dias / 365);
    let meses = ((dias % 365) / 30);
    let dia = (dias % 365 % 30);

    h3Resultado.innerHTML= "Estamos h&aacute; " + anos.toFixed(0) + " ano(s)," + "&nbsp;" + meses.toFixed(0) + " mes(es)" + " e " + dia.toFixed(0) + " dia(s) sem acidentes.";
}
btCalcular.onclick = function(){    
    calcularTotalDias();
}