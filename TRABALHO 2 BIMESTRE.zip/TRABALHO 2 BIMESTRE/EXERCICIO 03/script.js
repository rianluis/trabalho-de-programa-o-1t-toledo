let inputQtdPao = document.querySelector("#inputQtdPao");
let inputQtdBroas = document.querySelector("#inputQtdBroas");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotal(){
    let qtdPao = Number (inputQtdPao.value);
    let qtdBroas = Number (inputQtdBroas.value);

    let vendasDia = ((qtdPao * 0.12) + (qtdBroas * 1.50));
    let poupanca = vendasDia * (10/100);

    h3Resultado.innerHTML = 
    "Vendas totais do dia R$ " + vendasDia.toFixed(2) + "<br>"+
    "Total &agrave; guardar na poupan&ccedil;a R$ " + poupanca.toFixed(2) + "<br>";

}

btCalcular.onclick = function(){
    calcularTotal();
}