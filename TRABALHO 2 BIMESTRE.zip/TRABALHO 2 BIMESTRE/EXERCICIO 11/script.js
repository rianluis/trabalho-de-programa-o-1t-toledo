let inputVlrSaldo = document.querySelector("#inputVlrSaldo");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularReajuste(){
    let vlrSaldo = Number (inputVlrSaldo.value);

    let vlrAumento = (vlrSaldo +(vlrSaldo * (15/100)));    
    let vlrDesconto = (vlrAumento - (vlrAumento * (8/100))); 




    h3Resultado.innerHTML= "O sal&aacute;rio inicial &eacute;:  R$ " + vlrSaldo.toFixed(2) +"<br>" + " O sal&aacute;rio com reajuste de 15% &eacute;: R$ " + vlrAumento.toFixed(2) + 
    "<br>" + "O sal&aacute;rio final &eacute;:  R$ " + vlrDesconto.toFixed(2)
}

btCalcular.onclick = function(){
    calcularReajuste();
}

    
