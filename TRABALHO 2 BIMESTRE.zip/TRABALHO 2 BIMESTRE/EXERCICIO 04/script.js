let inputNome = document.querySelector("#inputNome");
let inputIdade = document.querySelector("#inputIdade");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function calcularTotalDias(){
    let nome = String (inputNome.value);
    let idade = Number (inputIdade.value);

    h3Resultado.innerHTML= nome + ", voc&ecirc; j&aacute; viveu "+ (idade * 365) + " dias.";
}

btCalcular.onclick = function(){
calcularTotalDias();
}   