let inputQtdadeCavalos = document.querySelector ("#inputQtdadeCavalos");
let inputbtCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function calcularTotalFerraduras(){
    let QtdadeCavalos = Number (inputQtdadeCavalos.value);

    h3Resultado.innerHTML= "Ser&atilde;o necess&aacute;rias: "+ (QtdadeCavalos * 4) + " ferraduras.";
}

btCalcular.onclick = function(){
    calcularTotalFerraduras();
}